package br.edu.ifpr.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//padrao Factory
//padrao singleton
public class ConnectionFactory {
    private static Connection conexao;

    //o construtor e privado
    private ConnectionFactory() {
    }

    public static Connection getConnection() {
        if (conexao == null) {
            String url = "jdbc:mysql://localhost:3306/agenda";
            String user = "aluno";
            String password = "aluno";
            try {
                conexao = DriverManager.getConnection(url, user, password);
                System.out.println("conectado ao banco de dados");
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return conexao;
    }
    
}
