package br.edu.ifpr.controller;

import br.edu.ifpr.model.Contato;
import br.edu.ifpr.model.dao.ContatoDAO;

public class ContatoController {
    ContatoDAO dao;

    public ContatoController(){
        this.dao = new ContatoDAO();
    }

    public void cadastrarContato(Contato contato){
        if (contato.getNome() == null || contato.getNome().isEmpty()) {
            System.out.println("nome não pode ser vazio");
            return;
        }

        dao.insert(contato);
    }
    
}