package br.edu.ifpr.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.edu.ifpr.model.Contato;

public class ContatoDAO {
    public void insert(Contato contato) {
        Connection con = ConnectionFactory.getConnection();

        try {
            String sql = "insert into contatos(nome, telefone, email) values (?, ?, ?)";
            PreparedStatement pst;
            pst = con.prepareStatement(sql);
            pst.setString(1, contato.getNome());
            pst.setString(2, contato.getTelefone());
            pst.setString(3, contato.getEmail());
            pst.executeUpdate();
            System.out.println("Contato salvo com sucesso!!");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
