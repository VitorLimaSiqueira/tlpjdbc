package br.edu.ifpr;

import br.edu.ifpr.controller.ContatoController;
import br.edu.ifpr.model.Contato;

public class Main {
    public static void main(String[] args) {
        System.out.println("Testando!");
        Contato contato = new Contato();
        ContatoController controller = new ContatoController();

        contato.setNome("Vitor");
        contato.setTelefone("9999");
        contato.setEmail("email");
        controller.cadastrarContato(contato);
        
    }
}